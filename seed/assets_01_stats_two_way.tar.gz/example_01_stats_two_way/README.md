# deg-two-way：组织×年龄 双向方差分析

## Purpose
对"完整表达矩阵.csv"（200 基因 × 27 样本）逐基因检验**组织（Liver/Muscle/Brain）、年龄（3M/12M/24M）及其交互**对表达的影响，识别差异基因、年龄趋势方向与方向不一致（交互）的基因。设计：3 组织 × 3 年龄 × 3 重复，完全平衡。

## Inputs
- `deg-two-way/input/expression_matrix.csv` — 来自 `uploads/完整表达矩阵.csv` 的复制件（24,300 B，Gene×样本，27 列 `<Tissue>_<Age>M_Rep<n>`）。

## Methods
1. 表达值做 `log2(x+1)` 变换。
2. 每个基因拟合 OLS：`expr ~ C(tissue) * C(age)`，用 `statsmodels.anova_lm(type=2)` 提取三个项的 F 与 p。
3. 效应量：partial η² = SS_term/(SS_term + SS_error)。
4. 多重比较：每项独立做 Benjamini–Hochberg FDR 校正（200 个检验），显著阈值 `padj < 0.05`。
5. 年龄方向：对每个基因×组织，用年龄组均值与年龄 3/12/24 的 Spearman ρ 及 `log2FC(24M−3M)` 判定 up/down/non_monotone；全局 up/down 按 3 组织平均 log2FC 符号计数。
6. PCA：基因 z 分数后 SVD，样本坐标 = U·s，PVE = s²/Σs²。
7. 图：figure-style 规范渲染（300 dpi，渲染后视觉校验）。

## Software and data sources
- Python 3.14.6（pixi 默认环境）；numpy 2.4.6；pandas 2.3.3；scipy 1.18.0；statsmodels 0.14.6；matplotlib 3.11.1；seaborn 0.13.2；pillow 12.3.0。
- 数据来源：用户上传 `uploads/完整表达矩阵.csv`（未在外部数据库登记）。

## Commands and scripts
- `deg-two-way/scripts/run_two_way_anova.py` — 在项目根执行：
  `pixi run python deg-two-way/scripts/run_two_way_anova.py`

## Outputs
- `output/tables/anova_all_genes.csv` — 每基因三项 F/p/padj、partial η²、组织/年龄组 log2 均值（200 行）。
- `output/tables/significance_summary.csv` — 各项显著基因计数。
- `output/tables/age_direction_summary.csv` — 年龄方向上/下计数（FDR<0.05）。
- `output/tables/age_trends_per_tissue.csv` — 每基因×组织的 Spearman ρ、log2FC、方向。
- `output/tables/top20_{tissue,age,interaction}.csv` — 各项 FDR 前 20。
- `output/tables/eda_sample_summary.csv` — 每样本文库大小/均值/标准差。
- `output/tables/summary.json` — 汇总指标。
- `output/figures/fig1_eda.png` — 测序深度（按组）、均值–方差（斜率≈2 支持 log 变换）、样本 PCA。
- `output/figures/fig2_heatmap_top30_age.png` — 年龄效应 FDR 前 30 基因的 z 分数热图（列注释组织/年龄）。
- `output/figures/fig3_volcano_age.png` — 年龄效应火山图（Δlog₂ 24M−3M vs −log10 p）。
- `output/figures/fig4_interaction_top4.png` — 交互 FDR 前 4 基因的组织×年龄折线（均值±SE，n=3）。

## Limitations
- 原始值单位为整数计数，已按标准做法 log2 变换；未做文库大小归一化（各样本总和接近，见 fig1a）。
- 数据整体效应极强（200/200 基因组织、年龄主效应 FDR 显著），疑似模拟数据；解读以效应量（η²、log2FC）与方向为主，勿过度解读 p 值本身。
- 无外部基因注释（Gene_1..Gene_200），未做通路分析。
